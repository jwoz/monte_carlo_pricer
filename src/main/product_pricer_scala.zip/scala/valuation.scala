class Valuation( volModel: VolatilityModel, product: Product )
{
  def value(): Double = ???
}
